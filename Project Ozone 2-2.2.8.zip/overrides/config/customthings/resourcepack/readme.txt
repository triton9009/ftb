This is the actual file used for resources in-game. 

Do not edit this, it will be created/deleted by the mod.